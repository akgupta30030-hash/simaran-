package com.simaran.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navy = Color(0xFF050B18)
            var status by remember { mutableStateOf("SIMARAN is ready") }
            MaterialTheme {
                Column(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(navy, Color(0xFF10284A), navy))
                    ).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("SIMARAN", color = Color.White, fontSize = 32.sp)
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.size(190.dp).background(
                            Brush.radialGradient(listOf(Color(0xFF8BE7FF), Color(0xFF168BFF), Color(0x22168BFF))),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(112.dp).background(Color(0xFF0B4F9C), CircleShape))
                    }
                    Spacer(Modifier.height(28.dp))
                    Text(status, color = Color(0xFFBDEBFF), fontSize = 16.sp)
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { status = "Voice and Qwen connection will be added next." }) {
                        Text("START SIMARAN")
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Offline AI integration is the next build step.", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}
